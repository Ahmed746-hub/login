package com.app.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    Button loginBtn;
    TextView signupBtn;
    TextInputEditText emailView;
    TextInputEditText passwordView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginBtn = this.findViewById(R.id.login_btn);
        signupBtn = this.findViewById(R.id.signup_btn);
        emailView = this.findViewById(R.id.email_view);
        passwordView = this.findViewById(R.id.password_view);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (emailView.getText().toString().isEmpty()){
                    Toast.makeText(LoginActivity.this, "Email is required!", Toast.LENGTH_SHORT).show();
                }
                else if(passwordView.getText().toString().isEmpty()){
                    Toast.makeText(LoginActivity.this, "Password is required!", Toast.LENGTH_SHORT).show();
                }
                else if(passwordView.getText().toString().length() < 6){
                    Toast.makeText(LoginActivity.this, "Password must contain 6 characters!", Toast.LENGTH_SHORT).show();
                }
                else{

                }

            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });

    }
}